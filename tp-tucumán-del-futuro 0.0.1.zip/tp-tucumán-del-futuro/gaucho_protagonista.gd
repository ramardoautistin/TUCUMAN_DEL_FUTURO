extends CharacterBody2D

var velocidad_normal = 200
var velocidad_dash = 1000
var velocidad = velocidad_normal

func _process(delta: float) -> void:
	var direccion = Vector2.ZERO
	if Input.is_action_just_pressed("esquivar"):
		velocidad = velocidad_dash
	if Input.is_action_just_released("esquivar"): 
		velocidad = velocidad_normal
	if Input.is_action_pressed("arriba"):
		direccion.y -= 1
	if Input.is_action_pressed("abajo"):
		direccion.y += 1
	if Input.is_action_pressed("izquierda"):
		direccion.x -= 1
	if Input.is_action_pressed("derecha"):
		direccion.x += 1
	
	position += direccion * velocidad * delta
