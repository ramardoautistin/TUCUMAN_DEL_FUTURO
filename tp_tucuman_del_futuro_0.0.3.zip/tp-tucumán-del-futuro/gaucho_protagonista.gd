extends CharacterBody2D

var velocidad_normal = 200
var velocidad_dash = 1000
var velocidad = velocidad_normal

@onready var sprite_2d: Sprite2D = $Sprite2D
@onready var colision_ataque: CollisionShape2D = $ZonaAtaque/CollisionShape2D
var esta_atacando: bool = false

func _process(delta: float) -> void:
	var direccion = Vector2.ZERO
	
	if Input.is_action_just_pressed("esquivar"):
		velocidad = velocidad_dash
	if Input.is_action_just_released("esquivar"): 
		velocidad = velocidad_normal
		
	if Input.is_action_pressed("arriba"):
		direccion.y -= 1
	if Input.is_action_pressed("abajo"):
		direccion.y += 1
	if Input.is_action_pressed("izquierda"):
		direccion.x -= 1
	if Input.is_action_pressed("derecha"):
		direccion.x += 1
	
	if direccion != Vector2.ZERO:
		direccion = direccion.normalized()
		rotation = direccion.angle()
	
	position += direccion * velocidad * delta
	
	if Input.is_action_just_pressed("golpe") and not esta_atacando:
		dar_golpe()
		
func dar_golpe() -> void:
	esta_atacando = true
	print("Puñetazo 🥊")
	
	colision_ataque.disabled = false
	
	get_tree().create_timer(0.2).timeout.connect(func():
		colision_ataque.disabled = true
		esta_atacando = false
)
