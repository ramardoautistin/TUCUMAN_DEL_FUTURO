
extends CanvasLayer

@onready var reintentar: Button = $Fondo/Reintentar
@onready var salir: Button = $Fondo/Salir


func _ready() -> void:
	hide()
	reintentar.pressed.connect(_on_reintentar_pressed)
	salir.pressed.connect(_on_salir_pressed)


func mostrar() -> void:
	var arbol := get_tree()

	if arbol == null:
		return

	show()
	arbol.paused = true


func _on_reintentar_pressed() -> void:
	get_tree().paused = false
	get_tree().reload_current_scene()


func _on_salir_pressed() -> void:
	get_tree().quit()
