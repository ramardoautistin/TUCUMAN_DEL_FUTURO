extends CanvasLayer

@onready var continuar: Button = $Fondo/Continuar
@onready var salir: Button = $Fondo/Salir

func _ready() -> void:
	hide()

	continuar.pressed.connect(_on_continuar_pressed)
	salir.pressed.connect(_on_salir_pressed)

func mostrar() -> void:
	show()
	get_tree().paused = true

func _on_continuar_pressed() -> void:
	get_tree().paused = false
	get_tree().reload_current_scene()

func _on_salir_pressed() -> void:
	get_tree().quit()
