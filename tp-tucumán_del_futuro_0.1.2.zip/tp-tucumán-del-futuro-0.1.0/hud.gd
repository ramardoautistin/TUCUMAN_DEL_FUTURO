
extends CanvasLayer

@onready var barra_vida: ProgressBar = $BarraVida
@onready var jugador = get_tree().get_first_node_in_group("jugador")
@onready var contador_enemigos: Label = $ContadorEnemigos

var spawner_actual: Node = null


func _ready() -> void:
	if jugador != null:
		barra_vida.max_value = jugador.health
		barra_vida.value = jugador.health

	contador_enemigos.text = "Enemigos restantes: 0"
	contador_enemigos.hide()


func _process(_delta: float) -> void:
	if is_instance_valid(jugador):
		barra_vida.value = jugador.health


func conectar_spawner(nuevo_spawner: Node) -> void:
	if is_instance_valid(spawner_actual):
		if spawner_actual.contador_actualizado.is_connected(_on_contador_actualizado):
			spawner_actual.contador_actualizado.disconnect(_on_contador_actualizado)

	spawner_actual = nuevo_spawner
	spawner_actual.contador_actualizado.connect(_on_contador_actualizado)

	contador_enemigos.hide()


func _on_contador_actualizado(restantes: int, total: int) -> void:
	if total <= 0:
		contador_enemigos.hide()
		return

	contador_enemigos.text = "Enemigos restantes: %d / %d" % [restantes, total]
	contador_enemigos.show()
