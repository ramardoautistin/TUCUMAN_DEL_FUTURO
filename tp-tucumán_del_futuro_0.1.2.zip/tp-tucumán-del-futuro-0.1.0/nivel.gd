
extends Node2D

@onready var player := $ContenedorActor/GauchoProtagonista
@onready var camara := $Camara2D
@onready var victoria = $Victoria

@export var velocidad_camara: float = 4.0

var total_encuentros: int = 0
var encuentros_completados: int = 0


func _ready() -> void:
	victoria.hide()

	var encuentros = get_tree().get_nodes_in_group("encuentros")
	total_encuentros = encuentros.size()

	for encuentro in encuentros:
		encuentro.encuentro_completado.connect(
			_on_encuentro_completado
		)

	print("Encuentros del nivel: ", total_encuentros)


func _process(delta: float) -> void:
	if is_instance_valid(player) and is_instance_valid(camara):
		camara.position = camara.position.lerp(
			player.position,
			velocidad_camara * delta
		)


func _on_encuentro_completado() -> void:
	encuentros_completados += 1

	print(
		"Encuentros completados: ",
		encuentros_completados,
		" / ",
		total_encuentros
	)

	if total_encuentros > 0 and encuentros_completados >= total_encuentros:
		mostrar_victoria()


func mostrar_victoria() -> void:
	if get_tree().paused:
		return

	print("¡NIVEL COMPLETADO!")
	victoria.mostrar()
