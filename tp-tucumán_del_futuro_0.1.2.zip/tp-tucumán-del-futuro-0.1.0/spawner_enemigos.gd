
extends Node2D

signal horda_eliminada
signal contador_actualizado(restantes: int, total: int)

@export var cantidad_enemigos: int = 3
@export var escena_enemigo: PackedScene

@export var posiciones: Array[Vector2] = [
	Vector2(400, 300),
	Vector2(600, 300),
	Vector2(800, 300),
	Vector2(1000, 300),
	Vector2(1200, 300)
]

var enemigos_generados: Array[Node] = []
var enemigos_restantes: int = 0
var total_enemigos: int = 0


func generar_enemigos() -> void:
	if escena_enemigo == null:
		push_error("No se asignó la escena del enemigo.")
		return

	var contenedor = get_tree().current_scene.get_node("ContenedorActor")
	var cantidad = mini(cantidad_enemigos, posiciones.size())
	total_enemigos = cantidad
	enemigos_restantes = cantidad
	contador_actualizado.emit(enemigos_restantes, total_enemigos)

	if cantidad == 0:
		horda_eliminada.emit()
		return

	for i in range(cantidad):
		var enemigo = escena_enemigo.instantiate()

		enemigo.tree_exited.connect(_on_enemigo_eliminado)

		contenedor.add_child(enemigo)
		enemigo.global_position = posiciones[i]
		enemigos_generados.append(enemigo)

	print("Enemigos generados: ", cantidad)
	print("Enemigos restantes: ", enemigos_restantes)


func _on_enemigo_eliminado() -> void:
	enemigos_restantes -= 1
	contador_actualizado.emit(enemigos_restantes, total_enemigos)

	print("Enemigos restantes: ", enemigos_restantes)

	if enemigos_restantes <= 0:
		enemigos_restantes = 0
		print("¡Horda eliminada!")
		horda_eliminada.emit()
