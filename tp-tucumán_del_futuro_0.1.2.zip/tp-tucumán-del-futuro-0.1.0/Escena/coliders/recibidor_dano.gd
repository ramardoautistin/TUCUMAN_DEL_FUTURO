class_name RecibidorDeDano
extends Area2D

signal dano_recibido(dano: int, direction: Vector2)
