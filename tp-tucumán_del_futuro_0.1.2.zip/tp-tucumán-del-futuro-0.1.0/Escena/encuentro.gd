
extends Node2D

signal encuentro_completado

var encuentro_activado := false

@onready var bloqueo = $Bloqueo/CollisionShape2D
@onready var spawner = $SpawnerEnemigos
@onready var hud = get_tree().current_scene.get_node("HUD")
@onready var filtro = get_tree().current_scene.get_node("HUD/FiltroCombate")


func _ready() -> void:
	spawner.horda_eliminada.connect(_on_horda_eliminada)


func _on_zona_activacion_body_entered(body: Node2D) -> void:
	if body.is_in_group("jugador") and not encuentro_activado:
		encuentro_activado = true

		filtro.show()
		bloqueo.set_deferred("disabled", false)

		hud.conectar_spawner(spawner)
		spawner.generar_enemigos()

		print("¡ENCUENTRO ACTIVADO!")


func _on_horda_eliminada() -> void:
	bloqueo.set_deferred("disabled", true)
	hud.get_node("ContadorEnemigos").hide()
	filtro.hide()

	encuentro_completado.emit()

	print("¡SECTOR DESBLOQUEADO!")
