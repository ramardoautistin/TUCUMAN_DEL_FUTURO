extends CharacterBody2D

@export var health : int
@export var damage : int
@export var speed : float

@onready var animacion_player := $AnimatedSprite2D
@onready var dano_emisor := $EmisorDano

# Obtenemos el CollisionShape2D dentro de EmisorDano
@onready var colision_dano: CollisionShape2D = $EmisorDano/CollisionShape2D
@onready var dano_recibidor: RecibidorDeDano = $RecibidorDano

enum State {Idle, Run, Punch}

var estado := State.Idle

func _ready() -> void:
	dano_emisor.area_entered.connect(on_emit_damage)
	animacion_player.animation_finished.connect(_on_animation_finished)
	dano_recibidor.dano_recibido.connect(on_receive_damage)
	# Nos aseguramos de que empiece desactivada
	colision_dano.disabled = true

func _process(_delta: float) -> void:
	control_input()
	control_movimiento()
	control_animacion()
	flip_sprites()
	move_and_slide()
	
func control_movimiento() -> void:
	if puede_mover():
		if velocity.length() == 0:
			estado = State.Idle
		else :
			estado = State.Run
	else:
		velocity = Vector2.ZERO
	
func control_input() -> void:
	var direccion := Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
	velocity = direccion * speed
	if puede_atacar() and Input.is_action_just_pressed("ataque"):
		estado = State.Punch
	
func control_animacion() -> void:
	if estado == State.Idle:
		animacion_player.play("Idle")
		colision_dano.disabled = true
	elif estado == State.Run:
		animacion_player.play("Run")
		colision_dano.disabled = true
	elif estado == State.Punch:
		animacion_player.play("Punch")
		colision_dano.disabled = false # Se activa solo al dar el puñetazo

func flip_sprites() -> void:
	if velocity.x > 0:
		animacion_player.flip_h = false
		dano_emisor.scale.x = 1
	elif velocity.x < 0:
		animacion_player.flip_h = true
		dano_emisor.scale.x = -1
		
func puede_mover() -> bool:
	return estado == State.Idle or estado == State.Run
		
func puede_atacar() -> bool:
	return estado == State.Idle or estado == State.Run
	
func _on_animation_finished() -> void:
	if estado == State.Punch:
		colision_dano.disabled = true # Se apaga al terminar el puñetazo
		estado = State.Idle

func on_emit_damage(dano_recibidor: RecibidorDeDano) -> void:
	# Evita que el personaje se haga daño a sí mismo
	if dano_recibidor.get_parent() == self:
		return

	var direction := Vector2.LEFT if dano_recibidor.global_position.x < global_position.x else Vector2.RIGHT

	dano_recibidor.dano_recibido.emit(damage, direction)

	print("¡Impacto confirmado en: ", dano_recibidor, "!")
	
func on_receive_damage(dano: int, direction: Vector2) -> void:
	health -= dano

	print("Daño recibido: ", dano)
	print("Vida restante: ", health)

	if health <= 0:
		queue_free()
