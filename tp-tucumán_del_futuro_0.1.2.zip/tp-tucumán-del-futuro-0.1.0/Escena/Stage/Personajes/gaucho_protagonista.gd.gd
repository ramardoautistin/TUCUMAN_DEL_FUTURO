extends "res://Escena/Stage/Personajes/personajes.gd"

func on_receive_damage(dano: int, direction: Vector2) -> void:
	health -= dano
	print("Daño recibido: ", dano)
	print("Vida restante: ", health)

	if health <= 0:
		game_over()

func game_over() -> void:
	var menu_game_over = get_tree().current_scene.get_node("GameOver")
	menu_game_over.mostrar()
