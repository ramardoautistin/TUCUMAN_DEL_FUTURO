
extends "res://Escena/Stage/Personajes/personajes.gd"

var objetivo: CharacterBody2D

@export var tiempo_entre_ataques: float = 1.5
@export var tiempo_recuperacion: float = 0.6

var cooldown_ataque: float = 0.0
var recuperacion_restante: float = 0.0


func _ready() -> void:
	super._ready()
	objetivo = get_tree().get_first_node_in_group("jugador")


func control_input() -> void:
	var delta := get_process_delta_time()

	# Reducir el tiempo de recuperación después del golpe.
	if recuperacion_restante > 0.0:
		recuperacion_restante -= delta
		velocity = Vector2.ZERO
		return

	# Reducir el tiempo entre ataques.
	if cooldown_ataque > 0.0:
		cooldown_ataque -= delta

	# Si no hay jugador, quedarse quieto.
	if not is_instance_valid(objetivo):
		velocity = Vector2.ZERO
		return

	var distancia := global_position.distance_to(objetivo.global_position)

	# Si el jugador está cerca, atacar cuando corresponda.
	if distancia <= 25.0:
		velocity = Vector2.ZERO

		if puede_atacar() and cooldown_ataque <= 0.0:
			estado = State.Punch
			cooldown_ataque = tiempo_entre_ataques
			recuperacion_restante = tiempo_recuperacion

		return

	# Si está lejos, perseguir al jugador.
	var direccion := global_position.direction_to(objetivo.global_position)
	velocity = direccion * speed
