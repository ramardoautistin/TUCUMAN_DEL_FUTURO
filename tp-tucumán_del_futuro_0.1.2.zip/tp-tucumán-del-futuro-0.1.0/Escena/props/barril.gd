extends StaticBody2D

@onready var damage_receiver := $RecibidorDano
@onready var sprite := $Sprite2D
@export var intencidad_del_retroceso : float

const gravedad := 500

enum State {IDLE, DESTROYED}

var height := 0.0
var height_speed := 0.0
var state := State.IDLE
var velocity := Vector2.ZERO

func _ready() -> void:
	damage_receiver.dano_recibido.connect(on_receive_damage.bind())
	
func _process(delta: float) -> void:
	position += velocity * delta
	sprite.position = Vector2.UP * height
	handle_air_time(delta)

func on_receive_damage(dano: int, direction: Vector2) -> void:
	if state == State.IDLE:
		sprite.frame = 1
		height_speed = intencidad_del_retroceso * 2
		state= State.DESTROYED
	velocity = direction * intencidad_del_retroceso
	
func handle_air_time(delta: float) -> void:
	if state == State.DESTROYED:
		modulate.a -= delta
		height += height_speed * delta
		if height < 0:
			height = 0
			queue_free()
		else:
			height_speed -= gravedad * delta
