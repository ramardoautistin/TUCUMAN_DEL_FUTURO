extends CharacterBody2D

var velocidad_normal = 200
var velocidad_dash = 1000
var velocidad = velocidad_normal
var vida = 10
var cantidad = 5

@onready var collision_ataque: CollisionShape2D = $AreaAtaque/ColisionAtaque

func _ready() -> void:
	collision_ataque.disabled = true
	add_to_group("gaucho_protagonista")
	#collision_ataque.body_entered.connect(_on_area_ataque_body_entered)

func _process(delta: float) -> void:
	var direccion = Vector2.ZERO
	if Input.is_action_just_pressed("esquivar"):
		velocidad = velocidad_dash
	if Input.is_action_just_released("esquivar"): 
		velocidad = velocidad_normal
	if Input.is_action_pressed("arriba"):
		direccion.y -= 1
	if Input.is_action_pressed("abajo"):
		direccion.y += 1
	if Input.is_action_pressed("izquierda"):
		direccion.x -= 1
		#$Sprite2D.flip = true
		scale.x = 1
	if Input.is_action_pressed("derecha"):
		direccion.x += 1
		scale.x = -1
		
	position += direccion * velocidad * delta
	
	var tam = get_viewport_rect().size
	position.x = clamp(position.x, 0, tam.x)
	position.y = clamp(position.y, 0, tam.y)

#Golpe de puño
	if Input.is_action_just_pressed("golpe"):
		ejecutar_puñetazo()
		
func recibir_dano(cantidad: int) -> void:
	vida -= cantidad
	if vida <= 0:
		return

func ejecutar_puñetazo() -> void:
	if collision_ataque && Input.is_action_just_pressed("golpe"):
		print("puñetazo")
		collision_ataque.disabled = false #Activa el collishionsahpe2d del golpe
	else:
		recibir_dano(cantidad)
	
	#tiempo de espera del puñetazo
	#get.tree().create_timer(0.15).timeout.connect(func(): collision_ataque.disabled = true)
	
func _on_area_ataque_body_entered(body: Node2D) -> void:
	if body.is_in_group("enemigo_uno"):
		print("Golpeaste")
		#if body.has_method("recibir_dano")
