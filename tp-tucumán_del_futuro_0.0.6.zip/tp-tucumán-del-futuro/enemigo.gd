extends Area2D
var velocidad := 100
var vida := 1
var dano := 10
@onready var timer: Timer = $Timer
@export var enemigo_escena: PackedScene
@export var radio := 700.0
	
func spawnear() -> void:
	var jugador = get_tree().get_first_node_in_group("player")
	if jugador == null:
		return
	var e = enemigo_escena.instantiate()
	e.global_position = jugador.global_position + Vector2.from_angle(randf() * TAU) * radio
	get_parent().add_child(e)

func _ready() -> void:
	$Timer.timeout.connect(spawnear)   # Timer: wait_time 1.0, autostart on
	add_to_group("enemigo")
	body_entered.connect(_on_body_entered)
	timer.timeout.connect(_on_timer_timeout)
	timer.wait_time = 1.0   # or set it in the Inspector
	timer.start()
	
func _process(delta: float) -> void:
	var jugador = get_tree().get_first_node_in_group("gaucho_protagonista")
	if jugador == null:
		return
	var direccion = (jugador.position - position).normalized()
	position += direccion * velocidad * delta

func _on_timer_timeout() -> void:
	print("tick")
	
func recibir_dano(cantidad: int) -> void:
	vida -= cantidad
	if vida <= 0:
		morir()
		
func morir() -> void:
	var jugador = get_tree().get_first_node_in_group("gaucho_protagonista")
	if jugador != null:
		jugador.sumar_kill()
		queue_free()
		
func _on_body_entered(body: Node) -> void:
	if body.is_in_group("gaucho_protagonista"):
		body.recibir_dano(dano)
		queue_free()
