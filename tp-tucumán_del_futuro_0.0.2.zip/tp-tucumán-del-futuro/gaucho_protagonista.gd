extends CharacterBody2D

var velocidad_normal = 200
var velocidad_dash = 1000
var velocidad = velocidad_normal

@onready var collision_ataque: CollisionShape2D = $AreaAtaque/ColisionAtaque

func _ready() -> void:
	collision_ataque.disabled = true
	#collision_ataque.body_entered.connect(_on_area_ataque_body_entered)

func _process(delta: float) -> void:
	var direccion = Vector2.ZERO
	if Input.is_action_just_pressed("esquivar"):
		velocidad = velocidad_dash
	if Input.is_action_just_released("esquivar"): 
		velocidad = velocidad_normal
	if Input.is_action_pressed("arriba"):
		direccion.y -= 1
	if Input.is_action_pressed("abajo"):
		direccion.y += 1
	if Input.is_action_pressed("izquierda"):
		direccion.x -= 1
		#$Sprite2D.flip = true
		scale.x = 1
	if Input.is_action_pressed("derecha"):
		direccion.x += 1
		scale.x = -1
		
	position += direccion * velocidad * delta

#Golpe de puño
	if Input.is_action_just_pressed("golpe"):
		ejecutar_puñetazo()

func ejecutar_puñetazo() -> void:
	print("puñetazo")
	collision_ataque.disabled = false #Activa el collishionsahpe2d del golpe
	
	#tiempo de espera del puñetazo
	#get.tree().create_timer(0.15).timeout.connect(func(): collision_ataque.disabled = true)
	
func _on_area_ataque_body_entered(body: Node2D) -> void:
	if body.is_in_group("enemigo_uno"):
		print("Golpeaste")
		#if body.has_method("recibir_dano")
