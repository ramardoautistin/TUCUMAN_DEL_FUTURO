extends Node2D

@onready var player := $ContenedorActor/GauchoProtagonista
@onready var camara := $Camara2D

@export var velocidad_camara: float = 4.0

func _process(delta: float) -> void:
	camara.position = camara.position.lerp(player.position, velocidad_camara * delta)
