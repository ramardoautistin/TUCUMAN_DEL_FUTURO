extends CharacterBody2D

@export var health : int
@export var damage : int
@export var speed : float

@onready var animacion_player := $AnimatedSprite2D
@onready var dano_emisor := $EmisorDano
@onready var recibidor_dano: RecibidorDeDano = $RecibidorDeDano

var jugador: CharacterBody2D = null

# Obtenemos el CollisionShape2D dentro de EmisorDano
@onready var colision_dano: CollisionShape2D = $EmisorDano/CollisionShape2D

enum State {Idle, Run, Punch}

var estado := State.Idle

# Señal para notificar al Spawner cuando este enemigo muere
signal enemigo_muerto

func _ready() -> void:
	dano_emisor.area_entered.connect(on_emit_damage)
	animacion_player.animation_finished.connect(_on_animation_finished)
	# Nos aseguramos de que empiece desactivada
	colision_dano.disabled = true
	# Buscamos al jugador en la escena principal
	jugador = get_tree().get_first_node_in_group("Jugador")
	
	# Conectamos la señal de recibir daño
	if recibidor_dano:
		recibidor_dano.dano_recibido.connect(tomar_dano)

func _process(_delta: float) -> void:
	control_input()
	control_movimiento()
	control_animacion()
	flip_sprites()
	move_and_slide()
	
func _physics_process(_delta: float) -> void:
	if jugador:
		# Calculamos la dirección hacia el GauchoProtagonista
		var direccion = (jugador.global_position - global_position).normalized()
		velocity = direccion * speed
		
		# Orientación de sprites
		if velocity.x > 0:
			animacion_player.flip_h = false
		elif velocity.x < 0:
			animacion_player.flip_h = true
			
		move_and_slide()
	
func control_movimiento() -> void:
	if puede_mover():
		if velocity.length() == 0:
			estado = State.Idle
		else :
			estado = State.Run
	else:
		velocity = Vector2.ZERO
	
func control_input() -> void:
	var direccion := Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
	velocity = direccion * speed
	if puede_atacar() and Input.is_action_just_pressed("ataque"):
		estado = State.Punch
	
func control_animacion() -> void:
	if estado == State.Idle:
		animacion_player.play("Idle")
		colision_dano.disabled = true
	elif estado == State.Run:
		animacion_player.play("Run")
		colision_dano.disabled = true
	elif estado == State.Punch:
		animacion_player.play("Punch")
		colision_dano.disabled = false # Se activa solo al dar el puñetazo

func flip_sprites() -> void:
	if velocity.x > 0:
		animacion_player.flip_h = false
		dano_emisor.scale.x = 1
	elif velocity.x < 0:
		animacion_player.flip_h = true
		dano_emisor.scale.x = -1
		
func puede_mover() -> bool:
	return estado == State.Idle or estado == State.Run
		
func puede_atacar() -> bool:
	return estado == State.Idle or estado == State.Run
	
func _on_animation_finished() -> void:
	if estado == State.Punch:
		colision_dano.disabled = true # Se apaga al terminar el puñetazo
		estado = State.Idle

func  on_emit_damage(dano_recibidor: RecibidorDeDano) -> void:
	var direction := Vector2.LEFT if dano_recibidor.global_position.x < global_position.x else Vector2.RIGHT 
	#Incrementa el puntaje
	dano_recibidor.dano_recibido.emit(damage, direction)
	print("¡Impacto confirmado en: ", dano_recibidor, "!")
	
func tomar_dano(cantidad: int, _direccion: Vector2) -> void:
	health -= cantidad
	print("Creatura recibió ", cantidad, " de daño. Salud restante: ", health)
	
	if health <= 0:
		morir()
		
func morir() -> void:
	enemigo_muerto.emit() # Le avisamos al Spawner
	queue_free() # Destruye el nodo del enemigo
