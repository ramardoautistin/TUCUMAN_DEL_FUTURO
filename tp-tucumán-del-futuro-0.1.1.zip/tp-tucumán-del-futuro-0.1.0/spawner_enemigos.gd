extends Node2D

@export var escena_creatura: PackedScene # Arrastra Creatura.tscn en el Inspector
@export var punto_spawn: Node2D # Posición donde aparecerán

@onready var timer_spawn: Timer = $TimerSpawn

var max_enemigos_pantalla: int = 6
var total_enemigos_nivel: int = 30

var enemigos_activos: int = 0
var enemigos_generados: int = 0

func _ready() -> void:
	timer_spawn.wait_time = 10.0 # 1 enemigo cada 10 segundos
	timer_spawn.timeout.connect(_on_timer_spawn_timeout)
	timer_spawn.start()
	
	# Intentar spawnear el primero inmediatamente
	intentar_spawnear()

func _on_timer_spawn_timeout() -> void:
	intentar_spawnear()

func intentar_spawnear() -> void:
	# Verificamos los límites: máximo 6 en escena y 30 en total
	if enemigos_activos < max_enemigos_pantalla and enemigos_generados < total_enemigos_nivel:
		spawnear_enemigo()

func spawnear_enemigo() -> void:
	if escena_creatura == null:
		return
		
	var nueva_creatura = escena_creatura.instantiate()
	
	# Posicionar la creatura en la ubicación del Spawner
	if punto_spawn:
		nueva_creatura.global_position = punto_spawn.global_position
	else:
		nueva_creatura.global_position = global_position
		
	# Escuchar cuando esta creatura en específico muera
	nueva_creatura.enemigo_muerto.connect(_on_enemigo_muerto)
	
	get_parent().add_child(nueva_creatura)
	
	enemigos_activos += 1
	enemigos_generados += 1
	print("Enemigo generado (", enemigos_generados, "/", total_enemigos_nivel, "). Activos en pantalla: ", enemigos_activos)

func _on_enemigo_muerto() -> void:
	enemigos_activos -= 1
	print("Enemigo eliminado. Quedan activos: ", enemigos_activos)
	
	# Si el temporizador estaba detenido porque alcanzamos el límite, lo reiniciamos
	if timer_spawn.is_stopped() and enemigos_generados < total_enemigos_nivel:
		timer_spawn.start()
